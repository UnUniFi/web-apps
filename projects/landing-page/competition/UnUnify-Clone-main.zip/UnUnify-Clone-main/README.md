## UnUnify Clone Website Challenge

This is the prototype code of the UnUnify Challenge.
The code was written using the Given Figma design as inspiration.
Feel free to clone and check out the code and design structures. Your feedback will go a long way.
